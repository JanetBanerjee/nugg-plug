
require 'carrierwave/orm/activerecord'