Koala.configure do |config|
  config.access_token = "EAAFPUZACblb0BAIyUbdKdxiqelmoZBzFF6Vs7ZCRFiwe3Xx0QcSY7TtcwXdnGbWKM2Hf6kVsUtP8eKlsxqoLXTiZAwHREMe5g9bAaFd9hTRbr02CoWiiumtifkByDhhrvWJYlH9Y51BjkWIGCiDKnn8Eis1jgmdErYWWeSIiPjzBAuQrieDnwaClZCgsrY5ZAIjZC3bMY3DewZDZD"
  config.app_access_token = "368686713771453|PtlQIKkQaSZH3DQ7pFxTNeEF8Qc"
  config.app_id = "368686713771453"
  config.app_secret = "1dfec019475d43711e8b8ba64a3fb3fc"
  # See Koala::Configuration for more options, including details on how to send requests through
  # your own proxy servers.
end