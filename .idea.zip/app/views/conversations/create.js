var conversations = $('#conversations-list');
var conversation = conversations.find("[data-conversation-id='" + "<%= @conversation.id %>" + "']");

if (conversation.length !== 1) {
    conversations.append("<%= j(render 'conversations/conversation', conversation: @conversation, user: current_user) %>");
    conversation = conversations.find("[data-conversation-id='" + "<%= @conversation.id %>" + "']");
}

conversation.find('.panel-body').show();

var messages_list = conversation.find('.messages-list');
var height = messages_list[0].scrollHeight;
messages_list.scrollTop(height);