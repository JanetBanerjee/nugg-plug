class StaticController < ApplicationController
  def homepage

  end
end