class Payment < ApplicationRecord
end
